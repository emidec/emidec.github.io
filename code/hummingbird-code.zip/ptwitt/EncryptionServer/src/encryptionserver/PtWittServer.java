/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package encryptionserver;

import java.security.MessageDigest;
import java.sql.*;
import java.util.ArrayList;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Andrew
 */
public class PtWittServer {

//The following method is used to send a message, it stores the message on the database
//with the userID, ciphertext, tStar and eMail
public void sendToServer(String userID, String ct, String tStar, String eMail)
    {
        String dbQuery = "INSERT INTO storedmessages (userID, ciphertext, tStar, eMail) VALUES ('" + userID + "','"+ ct + "','" + tStar +"','"+ eMail +"')";
        try
        {
            Connection conn = getConn();
            PreparedStatement query = conn.prepareStatement("INSERT INTO storedmessages (userID, ciphertext, tStar, eMail) VALUES (?,?,?,?)");
            query.setString(1, userID);
            query.setString(2, ct);
            query.setString(3, tStar);
            query.setString(4, eMail);
            query.execute(dbQuery);
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

//Helper Function
public String bytetoBase64(byte[] cipherText)
{
    return new sun.misc.BASE64Encoder().encode(cipherText);
}

//This method adds a subscription to the database with a status of 0, this status refers to a new
//subscription request that is sent to the recipient with the M request.
    public void addSubscription(String clientID, String email, String tagName, String M, String destClientID, String destEmail, String id)
    {
        String status = "0";

        Connection conn = null;
        //String dbQuery = "UPDATE subscriptions set clientID = '" + clientID + "', email ='"+ email + "', status = '" + status +"' , M = '"+ M +"', destClientID = '"+ destClientID +"', destEmail = '"+destEmail+"', tagName = '"+tagName+"' WHERE id='" + id +"'";
        //String dbQuery = "Insert into subscriptions (clientID, email, status, M, destClientID, destEmail, tagName) values ('"+ clientID+ "','" + email + "','" + status +"','" + M +"','" + destClientID + "','" + destEmail + "','" + tagName + "')";

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("UPDATE subscriptions set clientID = ?, email =?, status = ? , M = ?, destClientID = ?, destEmail = ?, tagName = ? WHERE id=?");
            query.setString(1, clientID);
            query.setString(2, email);
            query.setString(3, status);
            query.setString(4, M);
            query.setString(5, destClientID);
            query.setString(6, destEmail);
            query.setString(7, tagName);
            query.setString(8, id);
            
            query.execute();
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }
    }

    //Updates the subscription to status of 1, meaning that the subscription has been
    //approved and the MPrime is now stored in the database for this subscription request
    public void updateSubscription(String MPrime, String id)
    {
        Connection conn = null;
        //String dbQuery = "Update subscriptions Set status = 1, MPrime = '" + MPrime + "' WHERE id=" + id;

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("Update subscriptions Set status = 1, MPrime = ? WHERE id=?");
            query.setString(1, MPrime);
            query.setString(2, id);
            query.execute();
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }
    }

    //This method updates the status of the subscription to 2 (finalized) and stores the tStar value
    public void finalizeSubscription(String tStar, String id)
    {
        //String dbQuery = "Update subscriptions Set status = 2, tag = '" + tStar + "' WHERE id=" + id;
        Connection conn = null;
        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("Update subscriptions Set status = 2, tag = ? WHERE id=?");
            query.setString(1, tStar);
            query.setString(2, id);
            query.execute();
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }
    }

    //This method is used to retrieve the users pending subscriptions for display
    public ArrayList getMySubscriptions(String ClientID)
    {
        Connection conn = null;
        ArrayList mySubscriptions = new ArrayList();

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("select clientID, M, id, tagName from subscriptions where status = 0 AND destClientID =?");
            query.setString(1, ClientID);
            //String dbQuery = "select clientID, M, id, tagName from subscriptions where status = 0 AND destClientID ='" + ClientID +"'";

            ResultSet results = query.executeQuery();

           while(results.next())
            {
               ArrayList entry = new ArrayList();
               entry.add(results.getString("clientID"));
               entry.add(results.getString("M"));
               entry.add(results.getString("id"));
               entry.add(results.getString("tagName"));


               mySubscriptions.add(entry);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        return mySubscriptions;
    }

     public ArrayList getMyPending(String ClientID)
    {
        Connection conn = null;
        ArrayList mySubscriptions = new ArrayList();

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("select destClientID, M, id, tagName from subscriptions where status = 0 AND clientID =?");
            //String dbQuery = "select destClientID, M, id, tagName from subscriptions where status = 0 AND clientID ='" + ClientID +"'";
            query.setString(1, ClientID);
                    
            ResultSet results = query.executeQuery();

           while(results.next())
            {
               ArrayList entry = new ArrayList();
               entry.add(results.getString("destClientID"));
               entry.add(results.getString("tagName"));

               mySubscriptions.add(entry);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        return mySubscriptions;
    }

    //This method is used to retrieve the users finalize subscriptions for display
    public ArrayList getMyFinalize(String ClientID)
    {
        Connection conn = null;
        ArrayList myFinalize = new ArrayList();

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("select destClientID, MPrime, id, tagName from subscriptions where status = 1 AND clientID =?");
            //String dbQuery = "select destClientID, MPrime, id, tagName from subscriptions where status = 1 AND clientID ='" + ClientID +"'";
            query.setString(1, ClientID);

            ResultSet results = query.executeQuery();

           while(results.next())
            {
               ArrayList entry = new ArrayList();
               entry.add(results.getString("destClientID"));
               entry.add(results.getString("MPrime"));
               entry.add(results.getString("id"));
               entry.add(results.getString("tagName"));

               myFinalize.add(entry);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        return myFinalize;
    }

    //helper function that is used to retrieve a database connection
    private Connection getConn()
    {
        Connection conn = null;

        String url = "jdbc:mysql://localhost:3306/ptwittdb"; // a JDBC url
        //String username = "root";
        String username = "sproutmember";
        //String password = "password";
        String password = "2k11sprout2k11";

        try {
        // Load the JDBC driver
            try{
                Class.forName("org.gjt.mm.mysql.Driver");
                //Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
                System.out.println("bad Driver: " + e);
            }

            conn = DriverManager.getConnection(url, username, password);
            System.out.println("connection stablished");


        } catch (SQLException e) {
        System.out.println("bad conn: " + e);
        }
        return conn;
    }

    //helper function
    private byte[] base64toByte(String text)
    {
        System.out.println("Encoding: " + text);
        byte [] cipherText = null;
        try
        {
            cipherText = new sun.misc.BASE64Decoder().decodeBuffer(text);
        }
        catch(Exception e)
        {

        }
        System.out.println("Result: " + cipherText);
        return cipherText;
    }

    //Retrieves users information (currently just e-mail and public key variables) based on login
    public String [] getUserInfo(String login)
    {
        Connection conn = getConn();
        String [] userInfo = new String[4];

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("select clientId, email, e, N from users where clientID = ?");
            query.setString(1, login);
            //String dbQuery = "select clientId, email, e, N from users where clientID = '" +login+ "'";

            ResultSet results = query.executeQuery();
            results.next();
            userInfo[0] = results.getString("clientID");
            userInfo[1] = results.getString("eMail");
            userInfo[2] = results.getString("e");
            userInfo[3] = results.getString("N");
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return userInfo;
    }

    //This validates a user by returning an array or clientID and e-mail,
    //if it is empty then user does not exist or login/password combination is incorrect
    public String [] validateUser(String login, String password) throws SQLException
    {
        
        Connection conn = getConn();
        String [] userInfo = new String[3];
        
        conn = getConn();
        PreparedStatement query =  conn.prepareStatement("select clientId, eMail from users where clientID = ? AND password = ?");
        query.setString(1, login);
        query.setString(2, password);
        ResultSet results = query.executeQuery();
  
        //Statement query = conn.createStatement();
        //String dbQuery = "select clientId, eMail from users where clientID = '" +login+ "' AND password = '" + password + "'";
        //query.executeQuery(dbQuery);
       
        //ResultSet results = query.executeQuery(dbQuery);
        results.next();
        userInfo[0] = results.getString("clientID");
        userInfo[1] = results.getString("eMail");
        userInfo[2] = UUID.randomUUID().toString();
        
        //dbQuery = "update users set sessionID = '"+ userInfo[2] +"' where clientID = '" +login+ "' AND password = '" + password + "'";
        if(!userInfo[0].isEmpty())
        {
            query = conn.prepareStatement("update users set sessionID = ? where clientID = ? AND password = ?");
            query.setString(1, userInfo[2]);
            query.setString(2, login);
            query.setString(3, password);
            query.executeUpdate();
        }
        //query.executeQuery(dbQuery);
        
        conn.close();
        
        return userInfo;
    }
    
    public boolean confirmSession(String rand, String clientID)
    {
        Connection conn = getConn();
        try 
        {
            PreparedStatement statement = conn.prepareStatement("Select * from users where clientID = ? and sessionID = ?");
            statement.setString(1, clientID);
            statement.setString(2, rand);
            
            ResultSet results = statement.executeQuery();
            while(results.next())
                return true;
            
        } catch (Exception ex) 
        {
            return false;
        }
        
        return false;
    }

    //returns a list of current tags based on the login
    public ArrayList getMyTags(String login)
    {
        Connection conn = null;
        ArrayList tagInfo = new ArrayList();

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("select tag, tagName, destClientID, id from subscriptions where status = 2 AND clientID = ?");
            query.setString(1, login);
            //String dbQuery = "select tag, tagName, destClientID, id from subscriptions where status = 2 AND clientID = '" +login+ "';";
            //query.executeQuery(dbQuery);

            ResultSet results = query.executeQuery();

            while(results.next())
            {
               ArrayList entry = new ArrayList();
               entry.add(results.getString("tag"));
               entry.add(results.getString("tagName"));
               entry.add(results.getString("destClientID"));
               entry.add(results.getString("id"));

               tagInfo.add(entry);
            }
        }

        catch(Exception e)
        {
            System.out.println(e);
        }

        return tagInfo;
    }

    //returns stored messages with a given T* tag
    public ArrayList getMessages(String tStar)
    {
        tStar = tStar.replace(" ", "+");
        Connection conn = null;
        ArrayList cipherText = new ArrayList();

        try
        {
            conn = getConn();
            PreparedStatement query = conn.prepareStatement("select ciphertext from storedmessages where tStar = ?");
            query.setString(1, tStar);
            //String dbQuery = "select ciphertext from storedmessages where tStar = '"+ tStar +"';";
            //query.executeQuery(dbQuery);

            ResultSet results = query.executeQuery();

            while(results.next())
            {
               cipherText.add(results.getString("ciphertext"));
            }
        }

        catch(Exception e)
        {
            System.out.println(e);
        }

        return cipherText;
    }

    public void addNewUser(String e, String N, String clientID, String email, String pass) throws SQLException
    {
        //String dbQuery = "Insert Into users (e, N, password, clientID, email) Values ('" + e + "','" + N + "','" + pass + "','" + clientID + "','" + email + "');";
        Connection conn = null;
        
        conn = getConn();
        PreparedStatement query = conn.prepareStatement("Insert Into users (e, N, password, clientID, email) Values (?,?,?,?,?)");
        query.setString(1, e);
        query.setString(2, N);
        query.setString(3, pass);
        query.setString(4, clientID);
        query.setString(5, email);

        query.execute();
    }

    //creates a blank entry to get a new subscriptionID
    public int createNewSubscriptionID()
    {
        String dbQuery = "Insert Into subscriptions (clientID) Values (' ');";
        Connection conn = null;
        int id = 0;

        try
        {
            conn = getConn();
            Statement query = conn.createStatement();
            query.execute(dbQuery);
            ResultSet results = query.executeQuery("SELECT LAST_INSERT_ID() FROM subscriptions");
            results.next();
            id = results.getInt(1);
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString());
            id = -1;
        }

        return id;
    }
    
    public String hashPw(String pass)
    {
        try
        {
         byte[] passbytes = pass.getBytes();
            MessageDigest mdigest = MessageDigest.getInstance("MD5");
            mdigest.update(passbytes);
            byte hashBytes[] = mdigest.digest();
            StringBuffer sbuffer = new StringBuffer();
            for(int i =0; i < hashBytes.length; i++)
            {
                String temp = Integer.toHexString(0xff & hashBytes[i]);
                if(temp.length() == 1)
                    sbuffer.append('0');
                sbuffer.append(temp);
            }

            pass = sbuffer.toString();
            String[] result = null;
        }
        catch(Exception e)
        {
            return pass;
        }
        
        return pass;
    }
    
    public String encodeQuery(String url)
    {
        url = url.replaceAll("%", "%25");
        url = url.replaceAll(" ", "%20");
        //url = url.replaceAll('$', "%24");
        //url = url.replaceAll("&", "%26");
        url = url.replaceAll("#", "%23");
        
        url = url.replaceAll("@", "%40");
        url = url.replaceAll("`", "%60");
        url = url.replaceAll("/", "%2F");
        url = url.replaceAll(":", "%3A");
        url = url.replaceAll(";", "%3B");
        url = url.replaceAll("<", "%3C");
        url = url.replaceAll("=", "%3D");
        url = url.replaceAll(">", "%3E");
/*        url = url.replaceAll("?", "%3F");
        url = url.replaceAll("[", "%5B");
        url = url.replaceAll("\\", "%5C");
        url = url.replaceAll("]", "%5D");
        url = url.replaceAll("[", "%5B");
        url = url.replaceAll("^", "%5E");
        url = url.replaceAll("{", "%7B");
        url = url.replaceAll("|", "%7C");
        url = url.replaceAll("}", "%7D");
        url = url.replaceAll("~", "%7E");
        url = url.replaceAll("^", "%5E");
        url = url.replaceAll("^", "%5E");
        url = url.replaceAll("\"", "%22");
        url = url.replaceAll("'", "%27");
        url = url.replaceAll("+", "%2B");
        url = url.replaceAll(",", "%2C");*/
        
        return url;
    }
}
