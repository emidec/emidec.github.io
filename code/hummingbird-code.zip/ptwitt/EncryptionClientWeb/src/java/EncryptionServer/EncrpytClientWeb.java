package EncryptionServer;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;
import encryptionserver.PtWittServer;
import java.sql.SQLException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Andrew
 *
 * This class simply instantiates a copy of PtWittServer and provides methods that
 * allow the jsp page to talk to the methods in PtWittserver
 */

public class EncrpytClientWeb {


    PtWittServer enc = new PtWittServer();


    public void addSub(String clientID, String eMail, String tag, String M, String destClientID, String destEmail, String id)
    {
        enc.addSubscription(clientID, eMail, tag, M , destClientID, destEmail, id);
    }

    public void updateSub(String mPrime, String id)
    {
         enc.updateSubscription(mPrime ,id);
    }

    public ArrayList getMyFinalize(String myClientID)
    {
        return enc.getMyFinalize(myClientID);
    }

    public ArrayList getMySubscriptions(String clientID)
    {
        return enc.getMySubscriptions(clientID);
    }

    public void finalize(String tStar, String id)
    {
        enc.finalizeSubscription(tStar, id);
    }

    public void sendToServer(String clientID,String cipherText,String tStar,String eMail)
    {
        enc.sendToServer(clientID, cipherText, tStar, eMail);
    }

    private void sendEmail(String result)
    {
        String[] temp = result.split(";");
        if(temp.length < 3)
            return;
        ArrayList to = new ArrayList();
        String msg = temp[1];
        String tag = temp[2];

        for(int i = 0; i < temp.length; i=i+3)
        {
            to.add(temp[i]);
        }

        try
        {
        String host = "smtp.gmail.com";
        String from = "ptwitt1087@gmail.com";
        Properties props = System.getProperties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.password", "super10pass");
        props.put("mail.smtp.port", Integer.toString(587)); // 587 is the port number of yahoo mail
        props.put("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.starttls.enable", "true");

        Authenticator auth = new javax.mail.Authenticator() 
        {
           protected PasswordAuthentication getPasswordAuthentication() {
               return new PasswordAuthentication("ptwitt1087@gmail.com","super10pass" );
           }
           // Session s = Session.getInstance(props, javax.mail.Authenticator());
        };

        Session session = Session.getInstance(props, auth);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));

        InternetAddress[] to_address = new InternetAddress[to.size()];
        int i = 0;


        while(i < to.size())
        {
            to_address[i] = new InternetAddress(to.get(i).toString());
            i++;
        }

        System.out.println(Message.RecipientType.TO);
        i = 0;

            message.addRecipient(Message.RecipientType.TO, to_address[i]);
  
        message.setSubject("A Message from PTWITT");
        message.setText("CT:" + msg + "\n" + "T*:" + tag);
        Transport transport = session.getTransport("smtp");
        transport.connect(host, 587, from, "super10pass");
        transport.sendMessage(message, message.getAllRecipients());
        transport.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public String[] validateUser(String login, String password) throws SQLException
    {
        return enc.validateUser( login,  password);
    }

    public String[] getUserInfo(String login)
    {
        return enc.getUserInfo(login);
    }

    public ArrayList getMyTags(String login)
    {
        return enc.getMyTags(login);
    }

    public ArrayList getMessages(String tStar)
    {
        return enc.getMessages(tStar);
    }

    public void addNewUser(String e, String mod, String clientID, String email, String pass) throws SQLException
    {
        enc.addNewUser(e, mod, clientID, email, pass);
    }

    public int createNewSubscriptionID()
    {
        return enc.createNewSubscriptionID();
    }

    public ArrayList getMyPending(String clientID)
    {
        return enc.getMyPending(clientID);
    }
    
    public String hashPw(String pass)
    {
        return enc.hashPw(pass);
    }
    
    public boolean confirmSession(String sessID, String clientID)
    {
        return enc.confirmSession(sessID, clientID);
    }
    
    public String encodeQuery(String url)
    {
        return enc.encodeQuery(url);
    }
}
