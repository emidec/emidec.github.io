/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servicetester;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.security.*;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.crypto.digests.*;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
/**
 *
 * @author Andrew
 * This class it the main workhorse that does all encryption, decryption and key management.
 * It provides tools to Subscription Processor as well as being directly accessed by the
 * Firefox extension to encode/decode messages.
 *
 * Message encryption is defined as:

 * (message, t) → (ct, t*)

 * temp = Sha1-hash[RSA-Signature(message)]
 * k = MD5(temp || 0)
 * ct = AES_ENCk(message)

 * send (ct, t*) to database to recover search on t*

 * Message decryption is defined as:

 * (ct, t*) → (message, t)

 * t* = MD5(temp || 1)
 * k = MD5(temp || 0)
 * message = AES_DECk(ct)
 */
public class PtWittEnc {

private int length = 0;
private PrivateKey sk = null;
private PublicKey pk = null;
private KeyPair kp;

//constructs object nothing special
public PtWittEnc()
{

}

//This class uses the java.security.KeyPairGenerator to create a keypair.  This set is
//saved to the local computer at the location of file loc.
public boolean makeKeys(String fileLoc) throws Exception
{
        if(!new File(fileLoc + "\\pri.key").isFile()) //check if a private key file exists already
        {
            kp = KeyPairGenerator.getInstance("RSA").generateKeyPair();
            sk = kp.getPrivate();
            pk = kp.getPublic();

            writeToFile(fileLoc + "\\pub.key", getE(), getN());
            writeToFile(fileLoc + "\\pri.key", getD(), getN());
        }
        else
            return false;


    return true;
}

//helper function
public BigInteger getN()
{
    return ((RSAPrivateKey)sk).getModulus();
}

//helper function
public BigInteger getE()
{
    return ((RSAPublicKey)pk).getPublicExponent();
}

//helper function
public BigInteger getD()
{
    return ((RSAPrivateKey)sk).getPrivateExponent();
}

//helper function
public String getNasString()
{
    return ((RSAPrivateKey)sk).getModulus().toString();
}

//helper function
public String getEasString()
{
    return ((RSAPublicKey)pk).getPublicExponent().toString();
}

//helper function
public String getDasString()
{
    return ((RSAPrivateKey)sk).getPrivateExponent().toString();
}

//helper function
public PrivateKey getPrivateKey()
{
    return sk;
}

//helper function
public PublicKey getPublicKey()
{
    return pk;
}

//This fuction is used when loading a key from the keyfile stored on the local machine.
//It sets the private key of this class to be used later for various operations.
public void setPrivateKey(BigInteger N, BigInteger e)
{

    try
    {
        RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(N, e);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        sk = factory.generatePrivate(keySpec);
    }
    catch(Exception ex)
    {
        System.out.println(ex);
    }

    

}

//This function is used when loading a key from the keyfile that is stored locally
//it sets the public key to be used later.
public void setPublicKey(BigInteger N, BigInteger d)
{
    try
    {
       // byte[] currPk = Base64.decode(inPk);
       // pk = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(currPk));
        RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(N, d);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        sk = factory.generatePrivate(keySpec);
    }
    catch(Exception ex)
    {
        System.out.println(ex);
    }
}

//This method takes in a plaintext and returns a Sha1 encoded message, this method
//uses the instance "SHA1withRSA" signature algorithm
 public String getSha1Digest(String message)
    {
        String digest = "";
        try
        {
            byte[] inputByte = message.getBytes();
            MessageDigest hash = MessageDigest.getInstance("SHA1withRSA");

            ByteArrayInputStream byteStream = new ByteArrayInputStream(inputByte);
            DigestInputStream digestInStream = new DigestInputStream(byteStream, hash);
            ByteArrayOutputStream byteOutStream = new ByteArrayOutputStream();

            int val;
            val = digestInStream.read();
            while(val >= 0)
            {
                byteOutStream.write(val);
                val = digestInStream.read();
            }

            byte[] input = byteOutStream.toByteArray();
            System.out.println("in digest : " + new String(digestInStream.getMessageDigest().digest()));

            byteOutStream = new ByteArrayOutputStream();
            DigestOutputStream digestOutputStream = new DigestOutputStream(byteOutStream, hash);
            digestOutputStream.write(input);
            digestOutputStream.close();

             System.out.println("out digest: " + new String(digestOutputStream.getMessageDigest().digest()));
             digest = new String(digestOutputStream.getMessageDigest().digest());
        }
        catch(Exception e)
        {
            System.out.println("");
        }

        return digest;
    }

    //This method takes a plain text and returns a signature using the "SHA1withRSA" encryption method
    public byte[] sha1AndRSA(String plaintext)
    {
        byte[] signature = null;

        try
        {
            
            Signature sigInstance = Signature.getInstance(("SHA1withRSA"));
            sigInstance.initSign(sk);
            sigInstance.update((plaintext).getBytes());
            signature = sigInstance.sign();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        return signature;

    }

    //This method takes a plain text and returns a signature using the "SHA1" encryption method
    public byte[] sha1(String plaintext)
    {
        byte[] signature = null;

        try
        {

            Signature sigInstance = Signature.getInstance(("SHA1"));
            sigInstance.initSign(sk);
            sigInstance.update((plaintext).getBytes());
            signature = sigInstance.sign();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        return signature;

    }


    //Performs an MD5 hash with a 0 appended to the end of the input value.
    //this method is used during the message encryption to generate the K value
    //that is used for the AES encryption
    public byte[] hashMD5(byte[] input)
    {
        byte[] input2 = appendBytes(input, "0".getBytes());

        MD5Digest md5 = new MD5Digest();
        md5.update(input2, 0, input2.length);

        byte[] digest = new byte[md5.getDigestSize()];
        md5.doFinal(digest, 0);

        return digest;

    }

    //Does AES encryption on plain text using the provided key, this method uses
    //Bouncycastle as a provider and uses the "AES/ECB/PKCS7Padding" cipher instance
    //It returns a base64 encoded string of the ciphertext for more compact storage
    //in the database.
    public String encryptAES(String plainText, byte[] key)
    {
        BouncyCastleProvider provider = (new org.bouncycastle.jce.provider.BouncyCastleProvider());
        Security.addProvider(provider);
        byte[] input = plainText.getBytes();
        byte[] cipherText = null;
        SecretKeySpec secretKey = new SecretKeySpec(key, "AES");

        try
        {
            Cipher ci = Cipher.getInstance("AES/ECB/PKCS7Padding", "BC");
            ci.init(Cipher.ENCRYPT_MODE, secretKey);

            cipherText = new byte[ci.getOutputSize(input.length)];
            int ctLength = ci.update(input, 0, input.length, cipherText, 0);
            ctLength += ci.doFinal(cipherText, ctLength);

            length = ctLength;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        //return toHexCharArray(cipherText).toString();
        return new sun.misc.BASE64Encoder().encode(cipherText);
    }

    //This creates the T* value which is a common step during the encryption
    //decryption and subscription processes it is simply MD5(Temp || 1)
    public String createTStar(byte[] temp)
    {
       byte[] temp2 = appendBytes(temp, "1".getBytes());

        return new sun.misc.BASE64Encoder().encode(hashMD5(temp2));
    }

    //helper function
    public byte[] appendBytes(byte [] temp, byte [] zeroOrOne)
    {
        byte[] temp2 = new byte[temp.length + zeroOrOne.length];
        System.arraycopy(temp, 0, temp2, 0, temp.length);
        System.arraycopy(zeroOrOne, 0, temp2, zeroOrOne.length, zeroOrOne.length);

        return temp2;
    }

    //Decrypts the cipher text into plain text using bouncycastle as the provider
    //and using the AES/ECB/PKCS7Padding cipher instance.
    public String decryptAES(String text, byte[] key)
    {
        byte [] cipherText = null;
        try
        {
            cipherText = new sun.misc.BASE64Decoder().decodeBuffer(text);
        }
        catch(Exception e)
        {
            //do nothing
            return e.toString();
        }

        BouncyCastleProvider provider = (new org.bouncycastle.jce.provider.BouncyCastleProvider());
        Security.addProvider(provider);

        SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
        int ctLength = cipherText.length;;
        byte[] pt = null;
        try
        {
            Cipher ci = Cipher.getInstance("AES/ECB/PKCS7Padding", "BC");
            ci.init(Cipher.DECRYPT_MODE, secretKey);
            pt = new byte[ci.getOutputSize(ctLength)];
            int ptLength = ci.update(cipherText, 0, ctLength, pt, 0);
            ptLength += ci.doFinal(pt, ptLength);
        }
        catch(Exception e)
        {
            System.out.println(e);
            return e.toString();
        }

        return new String(pt);
    }

    //This method is used during the keyfile creation process to write out bytes out to files
    public void writeToFile(String fName, BigInteger exponent, BigInteger modulous) throws IOException
    {

        ObjectOutputStream output = null;
        try
        {
            output = new ObjectOutputStream(new FileOutputStream(fName, false));
            
            output.writeObject(modulous);
            output.writeObject(exponent);
        }
        catch(Exception e)
        {
            //something bad happened
        }
        finally
        {
            output.close();
        }
    }

    //This method loads a key file into the system setting the public and private key in the class
    public void loadKeyFile(String basePath)
    {
        try
        {

            FileInputStream inputPri = new FileInputStream(basePath + "\\pri.key");
            FileInputStream inputPub =  new FileInputStream(basePath + "\\pub.key");

            ObjectInputStream priStream = new ObjectInputStream(new BufferedInputStream(inputPri));
            ObjectInputStream pubStream = new ObjectInputStream(new BufferedInputStream(inputPub));

            BigInteger m = (BigInteger) pubStream.readObject();
            BigInteger e = (BigInteger) pubStream.readObject();
            BigInteger n = (BigInteger) priStream.readObject();
            n = (BigInteger) priStream.readObject();

            RSAPublicKeySpec pubSpec = new RSAPublicKeySpec(m, e);
            RSAPrivateKeySpec priSpec = new RSAPrivateKeySpec(m, n);

            KeyFactory kf = KeyFactory.getInstance("RSA");
            pk = kf.generatePublic(pubSpec);
            sk = kf.generatePrivate(priSpec);

            priStream.close();
            pubStream.close();
        }

        catch(Exception e)
        {
            //do nothing
        }
    }

    //This method is used when sending a message, it uses the encryptAES method
    //and returns a plaintext and tStar in an array.
    public String[] send(String tag, String plainText, String clientID, String eMail, String dStr, String NStr)
    {
        BigInteger N = new BigInteger(NStr);
        BigInteger d = new BigInteger(dStr);
        String [] output = new String[2];
        setPublicKey(N, d);
        try
        {
            byte [] temp = createTemp(d, N, tag);

            byte[] k = hashMD5(temp);
            String cipherText = encryptAES( plainText,k);

            String tStar = createTStar(temp);
            output[0] = cipherText;
            output[1] = tStar;
        }
        catch(Exception e)
        {
            //something is wrong..do nothing
        }

        return output;
    }

    //This method creates the 'temp' value which is defeind as SHA1(RSA-Signature(message))
     private byte[] createTemp(BigInteger d, BigInteger N, String tag)
     {
        byte [] temp = null;
        try
        {
            MessageDigest digest = MessageDigest.getInstance("SHA1");
            digest.update(tag.getBytes());
            byte[] result = digest.digest();
            BigInteger sha1Final = new BigInteger(1, result);

            BigInteger sigma = sha1Final.modPow(d, N);
            temp = sigma.toByteArray();
        }
        catch(Exception e)
        {
            //error in create temp do nothing
        }
        
        return temp;
     }

     //This method decrypts the AES encrypted messages with a given tag
     public String decryptStoredMessage(String input, String dStr, String NStr, String sigma)
     {
         //BigInteger N = new BigInteger(NStr);
         //BigInteger d = new BigInteger(dStr);
         //byte[]temp = createTemp( d,  N, tag);
         BigInteger sigmaTemp = new BigInteger(sigma);
         byte[] temp = sigmaTemp.toByteArray();
         byte[] key = hashMD5(temp);
         
         String result = "";
         result =  decryptAES(input, key);
         result = result.replaceAll("\uFFFD", "");

         return result;
     }

    public BigInteger generateR(BigInteger N, String fPath, int id)
    {
        SecureRandom rGenerator = null;
        byte [] rBytes;
        BigInteger r = null;
        ObjectOutputStream output = null;

        try
        {
            rGenerator = SecureRandom.getInstance("SHA1PRNG");
            rBytes = new byte [128];

            do
            {
                rGenerator.nextBytes(rBytes);
                r = new BigInteger(1, rBytes);

            }
            while(!(r.gcd(N)).equals(new BigInteger("1")));

            output = new ObjectOutputStream(new FileOutputStream(fPath + "\\rands" + id + ".key", false));
            output.writeObject(r);
            output.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return r;
    }

    public String getRasString(String N, String fName, String id)
    {
        int subId = Integer.parseInt(id);
        return generateR(new BigInteger(N), fName, subId).toString();
    }

    public String getSubscriptionRand(String id, String basePath) throws Exception
    {
        BigInteger r = null;
        basePath = basePath.replaceAll("[\n\r]", "");
        FileInputStream inputRands = new FileInputStream(basePath + "\\rands" + id + ".key");

        ObjectInputStream randsStream = new ObjectInputStream(new BufferedInputStream(inputRands));

        r = (BigInteger) randsStream.readObject();

        randsStream.close();

        return r.toString();
    }

    public String retrieveSigma(String id, String basePath) throws Exception
    {
        BigInteger sigma = null;
        basePath = basePath.replaceAll("[\n\r]", "");
        FileInputStream inputRands = new FileInputStream(basePath + "\\sigma" + id + ".key");
        ObjectInputStream sigmaStream = new ObjectInputStream(new BufferedInputStream(inputRands));
        sigma = (BigInteger) sigmaStream.readObject();
        sigmaStream.close();
        return sigma.toString();
    }
}
