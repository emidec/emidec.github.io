/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servicetester;

import java.math.BigInteger;

/**
 *
 * @author Andrew
 */
public class Main {

    /**
     * @param args the command line arguments
     */

    String d, M, N, r;

     public static void main(String[] args) {
         //Debugging Code Below
        try
        {
                 PtWittEnc enc = new PtWittEnc();
                /* SubscriptionProcessor sub = new SubscriptionProcessor();
                 enc.loadKeyFile("C:\\Users\\Andrew\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\v9np80ii.default\\extensions\\sample@example.net");

                 String e = enc.getEasString();
                 String N = enc.getNasString();
                 //String N = "111311242068620500520821899896116133540789300403687131636671302425111636475192788058230154516998007485855211476505462178930765654246170732309501199833387733738964837327692525758653202158626701232958445869398013681917820088462654361327948002986701000448208860499060813123997478646999861046256071042869983149097";
                 String d = enc.getDasString();

                 String R = "573229376316579144466255";// enc.getRasString(N, );

                 enc.getSubscriptionRand("112", "C:\\Users\\Andrew\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\v9np80ii.default\\extensions\\sample@example.net");

                 String M64 = sub.getRequestString(e, N, "Surfing", R);
                 BigInteger Mint = new BigInteger(new sun.misc.BASE64Decoder().decodeBuffer(M64));
                 String M = Mint.toString();
                 String mPrime64 = sub.getResponseString(d, M, N);
                 BigInteger mPrimeInt = new BigInteger(new sun.misc.BASE64Decoder().decodeBuffer(mPrime64));
                 String mPrime = mPrimeInt.toString();
                 String tStar = "";//debug: sub.processResponseString(mPrime, R, N);

                 String[] sendTStar = enc.send("Climbing", "Lets go Climbing", "Bob", "andrewmw@uci.edu", d, N);

                 if(sendTStar[1].toString().equals(tStar.toString()))
                 {
                     String test = "success!";
                 }
                 */

                 String input = "CHy2V6cK9F78lTJ9yWUuLA==";
                 String dStr = "1845793340557129126916403865205074604374965452804861018191026318442842205352464474468330500518598882297151140146108850166348453305103386723498387985016466374343243589451303682281123548547121410261183956841528969956669565163128208470846061417311254062615023009001482545324792803085750837706105880779223800825";
                 String NStr = "100638733910226765050516106583980843882630707887248067012633354269374833288007041816331926799074388476795669111277483954535755893724260112893439145901850400225574091044659592068360035883884208112311717732279936997666039570810175594900264666792277420383125164201056192349522046391849048276678001389251043107181";
                 String sigma = "16470749112871453514350369686327370158462047573806661606839928475445335299382493488677806947983836324380929262440699027654523347896390499270688803116862155936003475655211793868296787377474737903071008129883802196163384900813060704336050474237474402114524108108189737063085549113259927414582903307833863640745";

                 String plain = enc.decryptStoredMessage(input, dStr, NStr, sigma);

                 }


        // TODO code application logic here
        catch(Exception e)
        {

        }
    }

}
