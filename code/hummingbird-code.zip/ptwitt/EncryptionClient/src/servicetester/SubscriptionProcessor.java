/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servicetester;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
/**
 *
 * @author Andrew
 *
 * This class is designed encapsulate methods that are used in the subscription process.
 * Subscribe, Approve and Finalize.  It uses the methods from PtwittEnc to accomplish
 * this task and provide the Firefox extension an simplier way to do different subscription methods.
 */
public class SubscriptionProcessor {

    private PtWittEnc enc = new PtWittEnc();
    
    //Constructor generates random 'r' value from a using the java secruity secure random class with specified number of bits
    public SubscriptionProcessor()
    {
        
    }

    //This method prepares a subscription request and takes input for e, N and the tag value
    //and returns the ‘M’ value that is later sent to the destination client for approval.
    public BigInteger generateRequest(BigInteger e, BigInteger N, String tag, BigInteger r)
    {
        ////////////////////////////////////////////////////////////////
        /////////////////         PART ONE   ///////////////////////////
        //Do the Following Action: M = Sha1(Tag) * ((r^e) mod N) mod N//
        ////////////////////////////////////////////////////////////////

        BigInteger M = null;

        try
        {

        MessageDigest digest = MessageDigest.getInstance("SHA1");
        digest.update(tag.getBytes());
        byte[] result = digest.digest();
        BigInteger sha1Final = new BigInteger(1, result); //SHA1 Portion
        //int num = 65;
        BigInteger arr = r;
        //BigInteger arr = BigInteger.valueOf(num);

        BigInteger res= arr.modPow(e, N);
        M = (sha1Final.multiply(res)).mod(N);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return M;
    }

    //This method is a helper function that allows generateRequest to be called
    //using string values instead of BigInteger
    public String getRequestString(String eStr, String NStr, String tag, String rStr)
    {
        BigInteger e = new BigInteger(eStr);
        BigInteger N = new BigInteger(NStr);
        BigInteger r = new BigInteger(rStr);

        BigInteger M = generateRequest(e, N, tag, r);
        String mStr = new sun.misc.BASE64Encoder().encode(M.toByteArray());
        return mStr;
    }

    //Generates an approval value of M' using the subscription recipients d, M and N
    public BigInteger generateResponse(BigInteger d, BigInteger M, BigInteger N)
    {
        ////////////////////////////////////////////////////////////////
        /////////////////         PART TWO   ///////////////////////////
        //Do the Following Action: M' = (M^d) mod N/////////////////////
        ////////////////////////////////////////////////////////////////

        BigInteger mPrime = null;
        mPrime = M.modPow(d, N);
        return mPrime;
    }

    //This method is a helper function that allow getResponse to be called using string values instead of BigInteger
    public String getResponseString(String dStr, String MStr, String NStr)
    {
        String mPrimeStr = "";

        try
        {
            BigInteger d =  new BigInteger(dStr);
            BigInteger N =  new BigInteger(NStr);
            BigInteger M = new BigInteger(MStr);
            BigInteger mPrime = generateResponse(d, M, N);
            mPrimeStr = new sun.misc.BASE64Encoder().encode(mPrime.toByteArray());
        }
        catch(Exception e)
        {
            //problem with M
        }

        return mPrimeStr;
    }

    //This method does the finalize action, after a subscription is approved the initial user
    //will finalize the subscription.
    public String processResponse(BigInteger mPrime, BigInteger R, BigInteger N, String id, String filePath)
    {
        ////////////////////////////////////////////////////////////////
        /////////////////         PART THREE   /////////////////////////
        //Do the Following Action: T* = MD5(((m'/R) mod N) || '1') /////
        ////////////////////////////////////////////////////////////////

        BigInteger sigma = (mPrime.multiply(R.modInverse(N))).mod(N);
        sigmaToFile(sigma, filePath, id);
        byte[] temp = sigma.toByteArray();
        return enc.createTStar(temp);
    }

    //This is a helper function that allows process response to be called with String instead of BigInteger
    public String processResponseString(String mPrimeStr, String RStr, String NStr, String id, String filePath)
    {
        BigInteger mPrime = null;
        BigInteger R = null;
        BigInteger N = null;

        R = new BigInteger(RStr);
        N = new BigInteger(NStr);
        mPrime = new BigInteger(mPrimeStr);

        return processResponse(mPrime, R, N, id, filePath);
    }

    public void sigmaToFile(BigInteger sigma, String filePath, String id)
    {
         ObjectOutputStream output = null;

         try
         {
            output = new ObjectOutputStream(new FileOutputStream(filePath + "\\sigma" + id + ".key", false));
            output.writeObject(sigma);
            output.close();
         }
         catch(Exception e)
         {
             System.out.println(e);
         }
    }
}
