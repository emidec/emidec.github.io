// Dynamic rule IDs:
// 1 = global rule
// 1000+ = per-site rules (derived from hostname hash)
const GLOBAL_RULE_ID = 1;
const SITE_RULE_ID_BASE = 1000;

const CHROME_IOS_UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) " +
  "AppleWebKit/605.1.15 (KHTML, like Gecko) " +
  "CriOS/120.0.6099.0 Mobile/15E148 Safari/604.1";

// ---- Helpers ----

function buildUaRule({ id, urlFilter }) {
  return {
    id,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "User-Agent", operation: "set", value: CHROME_IOS_UA }
      ]
    },
    condition: {
      urlFilter,
      resourceTypes: [
        "main_frame",
        "sub_frame",
        "xmlhttprequest",
        "script",
        "image",
        "stylesheet",
        "font",
        "media",
        "object",
        "other"
      ]
    }
  };
}

// Simple stable hash to map hostname -> rule id slot.
// Keeps IDs within a safe range and avoids collisions in most real usage.
function hostnameToRuleId(hostname) {
  let hash = 0;
  for (let i = 0; i < hostname.length; i++) {
    hash = (hash * 31 + hostname.charCodeAt(i)) >>> 0;
  }
  // 0..9999 -> add base => 1000..10999
  return SITE_RULE_ID_BASE + (hash % 10000);
}

function siteUrlFilter(hostname) {
  // Matches http/https for this host and subdomains.
  // Example: "||example.com/" matches example.com and subdomains.
  return `||${hostname}/`;
}

async function getState() {
  const { uaOverrideEnabled, siteAllowlist } = await chrome.storage.local.get([
    "uaOverrideEnabled",
    "siteAllowlist"
  ]);
  return {
    uaOverrideEnabled: !!uaOverrideEnabled,
    siteAllowlist: Array.isArray(siteAllowlist) ? siteAllowlist : []
  };
}

async function setBadge(enabled) {
  await chrome.action.setBadgeBackgroundColor({ color: enabled ? "#2e7d32" : "#616161" });
  await chrome.action.setBadgeText({ text: enabled ? "iOS" : "" });
  await chrome.action.setTitle({
    title: enabled ? "UA Override: ON (Chrome iOS)" : "UA Override: OFF (Default UA)"
  });
}

async function applyGlobalRule(enabled) {
  if (enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [GLOBAL_RULE_ID],
      addRules: [buildUaRule({ id: GLOBAL_RULE_ID, urlFilter: "|http" })]
    });
  } else {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [GLOBAL_RULE_ID]
    });
  }
}

async function applySiteRules(siteAllowlist) {
  // Remove existing site rules (we’ll recreate from allowlist)
  // We only know our generated IDs by re-hashing allowlist.
  // Also try removing a broad range is not supported, so do deterministic remove.
  const removeRuleIds = siteAllowlist.map((h) => hostnameToRuleId(h));

  // First remove (safe even if not present), then add.
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });

  const addRules = siteAllowlist.map((hostname) =>
    buildUaRule({
      id: hostnameToRuleId(hostname),
      urlFilter: siteUrlFilter(hostname)
    })
  );

  if (addRules.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ addRules });
  }
}

async function setGlobalEnabled(enabled) {
  await chrome.storage.local.set({ uaOverrideEnabled: enabled });
  await applyGlobalRule(enabled);
  await setBadge(enabled);
}

async function toggleGlobalEnabled() {
  const { uaOverrideEnabled } = await getState();
  const next = !uaOverrideEnabled;
  await setGlobalEnabled(next);
  return next;
}

async function addSite(hostname) {
  const state = await getState();
  const next = Array.from(new Set([...state.siteAllowlist, hostname]));
  await chrome.storage.local.set({ siteAllowlist: next });
  await applySiteRules(next);
}

async function removeSite(hostname) {
  const state = await getState();
  const next = state.siteAllowlist.filter((h) => h !== hostname);
  await chrome.storage.local.set({ siteAllowlist: next });

  // Remove rule for this host id specifically, then reapply remaining
  const id = hostnameToRuleId(hostname);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [id] });
  await applySiteRules(next);
}

async function clearSites() {
  const state = await getState();
  const removeRuleIds = state.siteAllowlist.map((h) => hostnameToRuleId(h));
  await chrome.storage.local.set({ siteAllowlist: [] });
  if (removeRuleIds.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
  }
}

// Extract hostname from a tab URL safely
function hostnameFromUrl(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.hostname;
  } catch {
    return null;
  }
}

// ---- Context menus ----

const MENU = {
  TOGGLE_GLOBAL: "toggle_global",
  ENABLE_SITE: "enable_site",
  DISABLE_SITE: "disable_site",
  CLEAR_SITES: "clear_sites"
};

async function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU.TOGGLE_GLOBAL,
      title: "Toggle UA (Chrome iOS) — Global",
      contexts: ["action"]
    });
    chrome.contextMenus.create({
      id: MENU.ENABLE_SITE,
      title: "Enable UA (Chrome iOS) for this site",
      contexts: ["action"]
    });
    chrome.contextMenus.create({
      id: MENU.DISABLE_SITE,
      title: "Disable UA for this site",
      contexts: ["action"]
    });
    chrome.contextMenus.create({
      id: MENU.CLEAR_SITES,
      title: "Clear site rules",
      contexts: ["action"]
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info) => {
  const tab = info.tab;
  const hostname = tab?.url ? hostnameFromUrl(tab.url) : null;

  if (info.menuItemId === MENU.TOGGLE_GLOBAL) {
    await toggleGlobalEnabled();
    return;
  }

  if (info.menuItemId === MENU.CLEAR_SITES) {
    await clearSites();
    return;
  }

  if (!hostname) return;

  if (info.menuItemId === MENU.ENABLE_SITE) {
    await addSite(hostname);
  } else if (info.menuItemId === MENU.DISABLE_SITE) {
    await removeSite(hostname);
  }
});

// ---- Lifecycle ----

chrome.runtime.onInstalled.addListener(async () => {
  await createMenus();

  // Initialize state
  const { uaOverrideEnabled, siteAllowlist } = await getState();

  // Ensure rules reflect saved state
  await applyGlobalRule(uaOverrideEnabled);
  await applySiteRules(siteAllowlist);
  await setBadge(uaOverrideEnabled);
});

// Service worker can restart; restore badge/menus/rules
chrome.runtime.onStartup?.addListener(async () => {
  await createMenus();
  const { uaOverrideEnabled, siteAllowlist } = await getState();
  await applyGlobalRule(uaOverrideEnabled);
  await applySiteRules(siteAllowlist);
  await setBadge(uaOverrideEnabled);
});

// ---- Inputs ----

// Keyboard shortcut toggle (global)
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-ua") return;
  await toggleGlobalEnabled();
});

// Mouse toggle: click toolbar icon (global)
chrome.action.onClicked.addListener(async () => {
  await toggleGlobalEnabled();
});